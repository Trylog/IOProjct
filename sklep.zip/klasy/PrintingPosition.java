package sklep;

public class PrintingPosition {

	protected Product Product;
	protected int Quantity;

	public PrintingPosition(Product product, int quantity) {

		Product=product;
		Quantity=quantity;
	}
}
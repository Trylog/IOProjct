package sklep;

public class Application {
       static Bill bill= new Bill();
       static int cashierID = 32;
    public static void main(String[] args){

        bill.addPosition(Database.getProduct(2),2);
        bill.addPosition(Database.getProduct(2),2);
        bill.show();
        bill.calculatingFinalSums();
        System.out.println("\n\n\n");
        bill.addPosition(Database.getProduct(1),2);
        bill.removePosition(Database.getProduct(2),2);
        bill.show();
        bill.calculatingFinalSums();
        System.out.println("\n\n\n");
        Invoice x = new Invoice(bill,277277277,"Firma kox");
        x.printInvoice(cashierID);
    }

}


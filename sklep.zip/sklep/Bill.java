package sklep;

import sklep.PrintingPosition;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Bill {

	private ArrayList<InternalPosition> products;
	private int billId;
	private Date Date;

	Bill(){
		products=new ArrayList<InternalPosition>();
		billId  = (int) new Date().getTime();
		Date = new Date();
	}

	public void printHeader(int cashierID){
		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd hh:mm");
	System.out.println("Sklep Fajny");
	System.out.println("NIP 328957834275");
	System.out.println("Kasjer : "+cashierID);
	System.out.println(f.format(Date));

	}
	public void addPosition(Product product, int quantity) {

		for (var produt : products) {

			if(produt.getProductID()==product.getProductID()){
				produt.increment(quantity);
				return;
			}
		}
		products.add(new InternalPosition(product,quantity));
	}

	public void printPosition(PrintingPosition product) {
	System.out.println(product.Product.getName()+"	"+product.Quantity+"	"+product.Product.getPrice()+"	"+product.Product.getVAT());
	}

	public void show() {
		for (InternalPosition product:products) {
			System.out.println(product.Product.getName()+"	"+product.Quantity+"	"+product.Product.getPrice()+"	"+product.Product.getVAT());
		}
	}

	public void removePosition(Product product, int quantity) {
		for (var produt : products) {
			if (produt.getProductID() == product.getProductID()) {
				if (produt.Quantity > quantity)
					produt.decrement(quantity);
				else if (produt.Quantity == quantity) {
					products.remove(produt);
				}
				return;
			}
		}
	}

	public void calculatingFinalSums(){
		printSum(calcSum());;
		printTaxes(calcTaxes());

	}

	private float calcSum(){
		float sum = 0;
		for (var product : products){
			sum += product.Product.getPrice() * product.Quantity;
		}
		return sum;
	}
	private List<Float> calcTaxes() {
		List<Float> taxesSums = new ArrayList<>(List.of(0.0f, 0.0f, 0.0f, 0.0f));

		for (var product : products) {
			int index = switch (product.Product.getVAT()) {
				case A -> 0;
				case B -> 1;
				case C -> 2;
				case D -> 3;
			};

			taxesSums.set(index, taxesSums.get(index) + product.Product.getPrice() * product.Quantity * VATBracket.valueOf(product.Product.getVAT().name()).value / 100);
		}

		return taxesSums;
	}

	private void printSum(float sum){
		System.out.println("Suma: "+sum);
	}
	private void printTaxes(List<Float> taxesSums){

		System.out.println(VATBracket.valueOf("A")+"	"+taxesSums.get(0));
		System.out.println(VATBracket.valueOf("B")+"	"+taxesSums.get(1));
		System.out.println(VATBracket.valueOf("C")+"	"+taxesSums.get(2));
		System.out.println(VATBracket.valueOf("D")+"	"+taxesSums.get(3));

	}

}
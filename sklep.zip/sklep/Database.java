package sklep;

import java.util.ArrayList;
public class Database {
    static ArrayList<InternalPosition> magazyn;
     static{
        magazyn=new ArrayList<InternalPosition>();
        magazyn.add(new InternalPosition(new Product("Chleb pszenny",3.49f, VATBracket.B,1),36));
        magazyn.add(new InternalPosition(new Product("Mleko muuu",3.99f, VATBracket.B,2),314));
        magazyn.add(new InternalPosition(new Product("Telewizor 32''",1299.99f, VATBracket.A,3),4));
        magazyn.add(new InternalPosition(new Product("Radioodbiornik Rydzunio",333.33f, VATBracket.A,4),12));
    }
   public static Product getProduct(int id){
        Product product;
       for (InternalPosition x:magazyn) {
           if(x.Product.getProductID()==id){
               product=x.Product;
               return product;
           }
       }
        return null;
   }


}

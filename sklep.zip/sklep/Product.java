package sklep;

public class Product {

	private String Name;
	private float Price;
	private VATBracket VAT;
	private int ProductID;

	Product(String Name, float Price, VATBracket VAT, int ProductID){
		this.Name=Name;
		this.Price=Price;
		this.VAT=VAT;
		this.ProductID=ProductID;
	}

	public Product(Product Product) {
		this.ProductID=Product.ProductID;
		this.Name=Product.Name;
		this.VAT=Product.VAT;
		this.Price=Product.Price;


	}

	public Product() {
	}

	public String getName() {
		return Name;
	}


	public void setName(String Name) {
		this.Name=Name;
	}

	public float getPrice() {
		return Price;
	}

	public void setPrice(float Price) {
		this.Price=Price;
	}

	public VATBracket getVAT() {
		return VAT;
	}

	public void setVAT(VATBracket VAT) {
		this.VAT=VAT;
	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int ProductID) {
	this.ProductID=ProductID;
	}

}
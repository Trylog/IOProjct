package sklep;

public class PrintingPosition extends Product {

	protected Product Product;
	protected int Quantity;

	public PrintingPosition(Product product, int quantity) {

		Product=product;
		Quantity=quantity;
	}

}
package sklep;

import sklep.PrintingPosition;

import java.util.Scanner;

public class Application {
    static Scanner scan = new Scanner(System.in);

    private static void login(){}
    private static int scanProduct(){
        //System.out.println("Zeskanuj produkt");
        return scan.nextInt();
    }
    private static int insertQuantity(){
        System.out.println("Podaj ilosc");

        return scan.nextInt();
    }
    public void sendInvoice(Invoice Invoice, String Email){

    }
    public void addp(){
        Product product = Database.getProduct(scanProduct());
        Bill bill = new Bill();
        int q = insertQuantity();
        if(product!=null) {
            PrintingPosition printingPosition = new PrintingPosition(product, q);
            bill.printPosition(printingPosition);
            bill.addPosition(product, q);
        }
    }

    public static void main(String[] args){
        PrintingPosition printingPosition;
        int id, quantity;
        boolean koniec = false;
        Product product;
        login();
        Bill bill = new Bill();
        while(!koniec){
            id=scanProduct();
            quantity=insertQuantity();
            product= Database.getProduct(id);

            if(product!=null) {
                printingPosition = new PrintingPosition(product, quantity);
                bill.printPosition(printingPosition);
                bill.addPosition(product, quantity);
            }
            System.out.println("Jeszcze [T]/[N]");
            int y = scan.nextInt();
            if(y==0)koniec=true;
        }
        bill.printHeader(7382);
        bill.show();
        bill.calculatingFinalSums();
    }

}

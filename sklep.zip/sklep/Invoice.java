package sklep;

import sklep.Bill;

public class Invoice extends sklep.Bill {
    Bill Bill;
    int NIP;
    String CompanyName;

    public Invoice(Bill Bill,int NIP,String CompanyName){
        this.Bill=Bill;
        this.NIP = NIP;
        this.CompanyName = CompanyName;

    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TestSuite;

import org.junit.platform.suite.api.IncludeTags;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import sklep.ApplicationTest;
import sklep.BillTest;
import sklep.DatabaseTest;

/**
 *
 * @author matem
 */
@Suite
@SelectClasses({DatabaseTest.class,BillTest.class,ApplicationTest.class})
@IncludeTags("Basic")
public class BasicTests {
    
}

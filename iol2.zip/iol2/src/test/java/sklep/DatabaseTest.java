/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package sklep;


import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;


/**
 *
 * @author matem
 */
 @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DatabaseTest {
    private static Stream input() {
    return Stream.of(-1,0,10,20);
  }
     /**
     * Test of getProduct method, of class Database.
     * @param x
     */
    @ParameterizedTest
    @Order(0)
    @Tag("Basic")
    @Tag("Null")
    @Tag("Punkt1")
    @MethodSource("input")
    public void testGetProductNull(int x) {
        System.out.println("getProduct");
        int id = x;
        Product expResult = null;
        Product result = Database.getProduct(id);
        assertEquals(expResult, result);
    }
    /**
     * Test of getProduct method, of class Database.
     */
    @Test
    @Order(1)
    @Tag("Basic")
    @Tag("Punkt1")
    public void testGetProduct() {
        System.out.println("getProduct");
        int id = 0;
        Product expResult = null;
        Product result = Database.getProduct(id);
        assertEquals(expResult, result);
        id = 10;
        result = Database.getProduct(id);
        assertEquals(expResult, result);
        id = 4;
        expResult = new Product("Radioodbiornik Rydzunio",333.33f, VATBracket.C,4);
        result = Database.getProduct(id);
        
        assertEquals(expResult.getProductID(), result.getProductID());
        assertEquals(expResult.getName(), result.getName());
        assertEquals(expResult.getVAT(), result.getVAT());
        assertEquals(expResult.getPrice(), result.getPrice());
    }

    /**
     * Test of getProduct method, of class Database.
     */
    @Test
    @Order(2)
    @Tag("Basic")
    @Tag("Punkt1")
    public void testSaveBill() {
       System.out.println("saveBill");
       Bill bill = new Bill();
       
       Database.saveBill(bill);
       
       assertEquals(1,Database.bills.size());
       assertEquals(bill,Database.bills.get(0));      
    }
}

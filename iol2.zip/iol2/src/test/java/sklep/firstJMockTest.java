/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package sklep;
import mockit.Expectations;
import mockit.Mocked;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

/**
 *
 * @author micha
 */



public class firstJMockTest {
    
    public firstJMockTest() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Mocked
    Product product1;
    Product product2;
    @Test
    public void printingPos() {
        System.out.println("printing position test");
        
        new Expectations(){
            {
                product1.getName(); result = "Test product";
            }
        };
        PrintingPosition position1 = new PrintingPosition(product1, 1);
        assertEquals( "Test product", position1.getProduct().getName());    
    }
    @Test
    public void billGetQuantity(){
        
        new Expectations(){
            {
                product1.getProductID(); result = 1;
              
            }
        };
        Bill bill = new Bill();
        bill.addPosition(product1, 5);
       assertEquals(5, bill.getQuantity(1));
    }
    @Test
    public void internalPos(){
        
        InternalPosition internal = new InternalPosition(product1,3);
        internal.increment(2);
        
       assertEquals(5, internal.getQuantity());
    }
    @Test
    public void taxes(){
        Bill bill = new Bill();
        new Expectations(){
            {
                product1.getPrice(); result = 10;
                product1.getVAT(); result = VATBracket.B;
              
            }
        };
        bill.addPosition(product1, 1);
        ArrayList list = bill.taxes();
        ArrayList<Float> t = new ArrayList();
        t.add(0.0F);
        t.add(0.8F);
        t.add(0.0F);
        t.add(0.0F);
        assertEquals(t, list);
    }
   
}

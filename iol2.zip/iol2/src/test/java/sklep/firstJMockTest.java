/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package sklep;
import mockit.Expectations;
import mockit.Mocked;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.Tag;

/**
 *
 * @author micha
 */



public class firstJMockTest {
    
    public firstJMockTest() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Mocked
    Product product1;
    Product product2;
    @Test
    @Tag("Mocked")
    public void printingPos() {
        System.out.println("printing position test");
        
        new Expectations(){
            {
                product1.getName(); result = "Test product";
            }
        };
        PrintingPosition position1 = new PrintingPosition(product1, 1);
        assertEquals( "Test product", position1.getProduct().getName());    
    }
    @Test
    @Tag("Mocked")
    public void billGetQuantity(){
        
        new Expectations(){
            {
                product1.getProductID(); result = 1;
              
            }
        };
        Bill bill = new Bill();
        bill.addPosition(product1, 5);
       assertEquals(5, bill.getQuantity(1));
    }
    @Test
    @Tag("Mocked")
    public void internalPos(){
        
        InternalPosition internal = new InternalPosition(product1,3);
        internal.increment(2);
        
       assertEquals(5, internal.getQuantity());
    }
    @Test
    @Tag("Mocked")
    public void taxes(){
        Bill bill = new Bill();
        new Expectations(){
            {
                product1.getPrice(); result = 10;
                product1.getVAT(); result = VATBracket.B;
              
            }
        };
        bill.addPosition(product1, 1);
        ArrayList list = bill.taxes();
        ArrayList<Float> t = new ArrayList();
        t.add(0.0F);
        t.add(0.8F);
        t.add(0.0F);
        t.add(0.0F);
        assertEquals(t, list);
    }
       @Test
       @Tag("Mocked")
    public void sum(){
        Bill bill = new Bill();
        new Expectations(){
            {
                product1.getPrice(); result = 10;
            }
        };
        bill.addPosition(product1, 5);
        float expected =50;
        float actual = bill.sum();
        assertEquals(expected, actual);
        bill.addPosition(product1, 10);
        expected =150;
        actual = bill.sum();
        assertEquals(expected, actual);
    }
    
       @Test
       @Tag("Mocked")
    public void add(){
        Bill bill = new Bill();
        new Expectations(){
            {
                product1.getPrice(); result = 10;
                product1.getProductID(); result = 1;
            }
        };
        assertEquals(0,bill.products.size());
        bill.addPosition(product1, 5);
        assertEquals(1,bill.products.size());
                assertEquals(5,bill.products.get(0).getQuantity());
        assertEquals(1,bill.products.get(0).getProduct().getProductID());   
        assertEquals(10,bill.products.get(0).getProduct().getPrice());  
    }
    
       @Test
       @Tag("Mocked")
    public void remove(){
        Bill bill = new Bill();
        new Expectations(){
            {
                product1.getProductID(); result = 1;
            }
        };
        assertEquals(0,bill.products.size());
        bill.addPosition(product1, 5);
        assertEquals(1,bill.products.size());
        assertEquals(5,bill.products.get(0).getQuantity());      
        bill.removePosition(product1, -1);
        assertEquals(1,bill.products.size());
        assertEquals(4,bill.products.get(0).getQuantity());     
        bill.removePosition(product1, -4);
        assertEquals(0,bill.products.size());
    }
}

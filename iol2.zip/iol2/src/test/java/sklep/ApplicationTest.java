/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package sklep;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.api.extension.TestExecutionExceptionHandler;

/**
 *
 * @author matem
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ApplicationTest implements TestExecutionExceptionHandler{
    static Application app; 
    @BeforeEach
    public void setUp() {
        app = new Application();
        Database.bills = new ArrayList<>();
    }
    
    /**
     * Test of scanned method, of class Application.
     * @param id0
     * @param id1
     * @param id2
     * @param q0
     * @param id3
     * @param q1
     * @param q2
     * @param q3
     */
    @ParameterizedTest
    @Order(0)
    @Tag("Extensive")
    @Tag("Punkt3")
    @CsvSource({"1,1,1,1,4,4,4,4", "1,2,3,4,1,1,1,1", "1,1,2,2,2,2,2,2","4,1,2,1,1,2,1,2"})
    @ExtendWith(ApplicationTest.class)
    public void testScanned(int id0, int id1, int id2, int id3, int q0, int q1, int q2, int q3) {
        System.out.println("application test");
        
        app.scanned(id0);
        app.scanned(id1);
        app.scanned(id2);
        app.scanned(id3);
        app.scanned(-1);
        
        assertEquals(q0,app.bill.getQuantity(id0));
        assertEquals(q1,app.bill.getQuantity(id1));
        assertEquals(q2,app.bill.getQuantity(id2));
        assertEquals(q3,app.bill.getQuantity(id3));
    }
    
        /**
     * Test of finalize method, of class Application.
     * @param id0
     * @param id1
     * @param id2
     * @param q1
     * @param q0
     * @param q2
     * @param id3
     * @param q3
     */
    @ParameterizedTest
    @Order(1)
    @Tag("Extensive")
    @Tag("Punkt3")
    @CsvSource({"1,1,1,1,4,4,4,4", "1,2,3,4,1,1,1,1", "1,1,2,2,2,2,2,2","4,1,2,1,1,2,1,2"})
    public void testFinalize(int id0, int id1, int id2, int id3, int q0, int q1, int q2, int q3) {
        System.out.println("scanning test");
        
        Application.bill.addPosition(Database.getProduct(id0), q0);
        app.bill.addPosition(Database.getProduct(id1), q1);
        app.bill.addPosition(Database.getProduct(id2), q2);        
        app.bill.addPosition(Database.getProduct(id3), q3);
        
        app.Finalize();
        //int a = 1/0;
        
        assertEquals(app.bill,Database.bills.get(0));
    }

    @Override
    public void handleTestExecutionException(ExtensionContext ec, Throwable thrwbl) throws Throwable {
        if (thrwbl instanceof ArithmeticException) {  System.err.println("Caught Arithmeetic Exception");} else throw thrwbl;
    }
}

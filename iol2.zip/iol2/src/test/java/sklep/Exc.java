/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sklep;

import java.util.IllegalFormatCodePointException;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.TestExecutionExceptionHandler;

/**
 *
 * @author matem
 */
public class Exc implements TestExecutionExceptionHandler{
    @Override
    public void handleTestExecutionException(ExtensionContext ec, Throwable thrwbl) throws Throwable {
      
 if (thrwbl instanceof IndexOutOfBoundsException || thrwbl instanceof NullPointerException) { }
 else throw thrwbl;
 }
    
 } 
    


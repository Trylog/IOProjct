package sklep;

public interface BarcodeScanner {
    public int scan();
}

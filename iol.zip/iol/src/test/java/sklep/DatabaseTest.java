/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package sklep;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestMethodOrder;

/**
 *
 * @author matem
 */
 @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DatabaseTest {
    
    /**
     * Test of getProduct method, of class Database.
     */
    @Test
    @Order(0)
    @Tag("DatabaseTest")
    public void testGetProduct() {
        System.out.println("getProduct");
        int id = 0;
        Product expResult = null;
        Product result = Database.getProduct(id);
        assertEquals(expResult, result);
        id = 10;
        result = Database.getProduct(id);
        assertEquals(expResult, result);
        id = 4;
        expResult = new Product("Radioodbiornik Rydzunio",333.33f, VATBracket.C,4);
        result = Database.getProduct(id);
        
        assertEquals(expResult.getProductID(), result.getProductID());
        assertEquals(expResult.getName(), result.getName());
        assertEquals(expResult.getVAT(), result.getVAT());
        assertEquals(expResult.getPrice(), result.getPrice());
    }
    
    /**
     * Test of getProduct method, of class Database.
     */
    @Test
    @Order(1)
    @Tag("DatabaseTest")
    public void testSaveBill() {
       System.out.println("saveBill");
       Bill bill = new Bill();
       
       Database.saveBill(bill);
       
       assertEquals(1,Database.bills.size());
       assertEquals(bill,Database.bills.get(0));      
    }
}

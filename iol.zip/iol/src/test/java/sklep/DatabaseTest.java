/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package sklep;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author matem
 */
public class DatabaseTest {
    
    public DatabaseTest() {
    }
    
    @BeforeAll
    public static void setUpClass() { 
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getProduct method, of class Database.
     */
    @Test
    public void testGetProduct() {
        System.out.println("getProduct");
        int id = 0;
        Product expResult = null;
        Product result = Database.getProduct(id);
        assertEquals(expResult, result);
        id = 10;
        result = Database.getProduct(id);
        assertEquals(expResult, result);
        id = 4;
        expResult = new Product("Radioodbiornik Rydzunio",333.33f, VATBracket.C,4);
        result = Database.getProduct(id);
        assertEquals(expResult.getProductID(), result.getProductID());
        assertEquals(expResult.getName(), result.getName());
        assertEquals(expResult.getVAT(), result.getVAT());
        assertEquals(expResult.getPrice(), result.getPrice());
    }

}

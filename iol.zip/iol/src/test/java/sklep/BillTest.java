/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package sklep;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 *
 * @author matem
 */
 @TestMethodOrder(OrderAnnotation.class)
public class BillTest {
    Bill bill;
    public BillTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        bill=new Bill();
    }
    
    @AfterEach
    public void tearDown() {
    }


    /**
     * Test of addPosition method, of class Bill.
     */
    @Test
    public void testAddNull() {
        System.out.println("addPosition - null");
        bill.addPosition(null, 1); // dodanie null
        assertEquals(0,bill.products.size());
        Product p = Database.getProduct(1);
        bill.addPosition(p, 0); // dodanie o ilosci 0
        assertEquals(0,bill.products.size());
    }

    /**
     * Test of addPosition method, of class Bill.
     */
    @ParameterizedTest
    @CsvSource({"1,2", "2,3", "3,1","4,1"})
    @Order(1)
    public void testAddPosition(int id, int quanity) {
        System.out.println("addPosition");
        Product p = Database.getProduct(id);
        bill.addPosition(p, quanity);
        assertEquals(Database.getProduct(id),bill.products.get(0).getProduct());
        assertEquals(quanity,bill.products.get(0).getQuantity());
        bill.addPosition(p, quanity);
        assertEquals(Database.getProduct(id),bill.products.get(0).getProduct());
        assertEquals(2*quanity,bill.products.get(0).getQuantity());
        assertEquals(1,bill.products.size());
    }
    
    
    /**
     * Test of removePosition method, of class Bill.
     */
    @Test
    @Order(2)
    public void testRemovePosition() {
        System.out.println("removePosition");
        bill.addPosition(Database.getProduct(1), 2);
        bill.removePosition(Database.getProduct(1), -3);
        assertEquals(1,bill.products.size());
        assertEquals(2,bill.products.get(0).getQuantity());       
        bill.removePosition(Database.getProduct(1), -1);
        assertEquals(1,bill.products.size());
        assertEquals(1,bill.products.get(0).getQuantity());
        bill.removePosition(Database.getProduct(1), -1);
        assertEquals(0,bill.products.size());

        
    }

    /**
     * Test of sum method, of class Bill.
     */
    @ParameterizedTest
    @CsvSource({"1,2,2,3", "2,2,3,3", "3,1,2,4","2,1,3,1"})
    @Order(3)
    public void testSum(int id1, int id2, int q1,int q2) {
        System.out.println("sum");
        float suma = bill.sum();
        float expected;
        assertTrue(suma==0);
        bill.addPosition(Database.getProduct(id1), q1);
        expected=Database.getProduct(id1).getPrice()*q1;
        suma = bill.sum();
        assertEquals(expected,suma);
        bill.addPosition(Database.getProduct(id2), q2);
        suma=bill.sum();
        expected+=Database.getProduct(id2).getPrice()*q2;
        assertEquals(expected,suma);
    }
        /**
     * Test of taxes method, of class Bill.
     */
    @ParameterizedTest
    @Order(4)
    @CsvSource({"1,2,2,3,0,1.516,0,0", "2,2,3,3,0,1.9152,0,0", "3,1,2,4,597.99536,1.1168,0,0","2,4,3,1,0,0.9576,16.666498,0"})
    public void testTaxes(int id1, int id2, int q1,int q2,float e0,float e1,float e2,float e3) {
        System.out.println("taxes");
        bill.addPosition(Database.getProduct(id1), q1);
        bill.addPosition(Database.getProduct(id2), q2);
       ArrayList<Float> wyniki = bill.taxes();
       assertEquals(e0,wyniki.get(0));
       assertEquals(e1,wyniki.get(1));
       assertEquals(e2,wyniki.get(2));     
       assertEquals(e3,wyniki.get(3));
                     
                     
    }
}

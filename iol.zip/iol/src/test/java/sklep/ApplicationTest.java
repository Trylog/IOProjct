/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package sklep;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 *
 * @author matem
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ApplicationTest {
    static Application app; 
    @BeforeEach
    public void setUp() {
        app = new Application();
        Database.bills = new ArrayList<>();
    }
    
    /**
     * Test of scanned method, of class Application.
     * @param id0
     * @param id1
     * @param id2
     * @param q0
     * @param id3
     * @param q1
     * @param q2
     * @param q3
     */
    @ParameterizedTest
    @Order(0)
    @Tag("Scanned")
    @CsvSource({"1,1,1,1,4,4,4,4", "1,2,3,4,1,1,1,1", "1,1,2,2,2,2,2,2","4,1,2,1,1,2,1,2"})
    public void testScanned(int id0, int id1, int id2, int id3, int q0, int q1, int q2, int q3) {
        System.out.println("scanning test");
        
        app.scanned(id0);
        app.scanned(id1);
        app.scanned(id2);
        app.scanned(id3);
        
        assertEquals(q0,app.bill.getQuantity(id0));
        assertEquals(q1,app.bill.getQuantity(id1));
        assertEquals(q2,app.bill.getQuantity(id2));
        assertEquals(q3,app.bill.getQuantity(id3));
    }
    
        /**
     * Test of finalize method, of class Application.
     * @param id0
     * @param id1
     * @param id2
     * @param q1
     * @param q0
     * @param q2
     * @param id3
     * @param q3
     */
    @ParameterizedTest
    @Order(1)
    @Tag("Finalize")
    @CsvSource({"1,1,1,1,4,4,4,4", "1,2,3,4,1,1,1,1", "1,1,2,2,2,2,2,2","4,1,2,1,1,2,1,2"})
    public void testFinalize(int id0, int id1, int id2, int id3, int q0, int q1, int q2, int q3) {
        System.out.println("scanning test");
        
        app.bill.addPosition(Database.getProduct(id0), q0);
        app.bill.addPosition(Database.getProduct(id1), q1);
        app.bill.addPosition(Database.getProduct(id2), q2);        
        app.bill.addPosition(Database.getProduct(id3), q3);
       
        app.Finalize();
        
        assertEquals(app.bill,Database.bills.get(0));
    }
}
